export const server = "https://volaris.onrender.com//api/v2";
export const backend_url = "https://volaris.onrender.com/";

